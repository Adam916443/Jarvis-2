# Hey Jarvis wake-word model files

The debug build fetches these three compatible ONNX files automatically from the pinned
`openwakeword-wasm-browser@0.1.1` model bundle during `preDebugBuild`:

- `melspectrogram.onnx`
- `embedding_model.onnx`
- `hey_jarvis_v0.1.onnx`

The project code uses the openWakeWord inference pipeline. The pretrained Hey Jarvis model
is licensed **CC BY-NC-SA 4.0** (non-commercial, attribution, share-alike). The Gradle task
adds it to debug builds only. It is deliberately excluded from release APKs; do not use this
model in a commercial app or distribute a release build containing it.

The first debug build needs an internet connection to download the model files. After they
are cached in `app/build/generated/wake-assets`, later builds can reuse them.
