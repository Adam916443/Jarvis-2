package app.shilex.android.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import app.shilex.android.Diag

/** Re-arms the wake listener after reboot on Android 10 devices. */
class WakeBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        // Starting a microphone foreground service from boot is restricted on newer Android
        // versions. The app is designed for Android 10 phones; on newer versions, open it once
        // after reboot so Android grants the microphone while-in-use state from a visible screen.
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
            Diag.i("wake: open JARVIS once after reboot on Android 11 or newer")
            return
        }
        if (VoiceService.wakeWordWanted(context)) {
            Diag.i("wake: restoring after boot")
            VoiceService.start(context)
        }
    }
}
