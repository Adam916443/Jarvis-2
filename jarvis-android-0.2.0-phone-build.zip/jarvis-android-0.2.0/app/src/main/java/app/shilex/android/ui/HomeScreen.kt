package app.shilex.android.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.shilex.android.Branding
import app.shilex.android.assistant.Line
import app.shilex.android.assistant.Phase
import app.shilex.android.assistant.UiState
import app.shilex.android.learn.HabitKeys
import app.shilex.android.local.ActivityLog
import app.shilex.android.local.LocalCommand
import app.shilex.android.local.LocalPhase
import app.shilex.android.local.MediaKey
import app.shilex.android.task.Task
import app.shilex.android.wake.WakeWordModel

private val HudBackground = Color(0xFF030A14)
private val HudPanel = Color(0xFF071827)
private val HudLine = Color(0xFF14506A)
private val HudCyan = Color(0xFF43E9FF)
private val HudMuted = Color(0xFF80A7B9)
private val HudWarning = Color(0xFFFFB75E)

private data class Status(
    val title: String,
    val hint: String,
    val badge: String,
    val phase: Phase,
    val live: Boolean,
)

private fun status(state: UiState, local: LocalPhase, wakeOn: Boolean): Status = when {
    local == LocalPhase.Listening -> Status("LISTENING", "Speak now. Local command mode is active.", "ON DEVICE", Phase.Listening, true)
    local == LocalPhase.Doing -> Status("PROCESSING", "Executing a supported on-device command.", "ON DEVICE", Phase.Connecting, true)
    local == LocalPhase.Speaking -> Status("RESPONDING", "JARVIS is speaking.", "ON DEVICE", Phase.Speaking, true)
    state.phase == Phase.Connecting -> Status("CONNECTING", "Establishing secure voice link…", "GEMINI LINK", Phase.Connecting, true)
    state.phase == Phase.Listening -> Status("LISTENING", "Voice channel open. Speak naturally.", "VOICE LINK", Phase.Listening, true)
    state.phase == Phase.Speaking -> Status("RESPONDING", "Tap the reactor to interrupt.", "VOICE LINK", Phase.Speaking, true)
    else -> Status(
        "STANDBY",
        state.problem ?: if (wakeOn) "Wake phrase armed · say \"${WakeWordModel.PHRASE}\"" else "Wake phrase offline · tap the microphone",
        if (wakeOn) "SYSTEM ARMED" else "STANDBY",
        Phase.Off,
        false,
    )
}

@Composable
fun HomeScreen(
    state: UiState,
    localPhase: LocalPhase,
    level: Float,
    task: Task?,
    activity: List<ActivityLog.Entry>,
    wakeOn: Boolean,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onInterrupt: () -> Unit,
    onMicDenied: () -> Unit,
    onPermissionAnswered: (Boolean) -> Unit,
    onQuick: (LocalCommand) -> String,
    onSeeActivity: () -> Unit,
    favourites: List<LocalCommand> = emptyList(),
) {
    val context = LocalContext.current
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) onStart() else onMicDenied()
    }
    val askForTool = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission(), onPermissionAnswered)
    LaunchedEffect(state.permissionNeeded) { state.permissionNeeded?.let(askForTool::launch) }

    val startListening = {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) onStart() else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }
    val now = status(state, localPhase, wakeOn)
    val problem = state.problem != null && !now.live

    Column(
        Modifier.fillMaxSize().background(HudBackground).padding(horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", color = HudCyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("PERSONAL AI INTERFACE  /  V.0.2", color = HudMuted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            Row(
                Modifier.border(1.dp, HudLine, RoundedCornerShape(30.dp)).background(HudPanel, RoundedCornerShape(30.dp)).padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(Modifier.size(6.dp).background(if (now.live || wakeOn) HudCyan else HudMuted, CircleShape))
                Text(now.badge, color = if (now.live || wakeOn) HudCyan else HudMuted, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp)
            }
        }

        Box(
            Modifier.fillMaxWidth().weight(1f).padding(top = 2.dp, bottom = 2.dp),
            contentAlignment = Alignment.Center,
        ) {
            Orb(
                phase = now.phase,
                level = level,
                modifier = Modifier
                    .size(230.dp)
                    .semantics { contentDescription = "${Branding.ASSISTANT_NAME}: ${now.title}" }
                    .clickable(remember { MutableInteractionSource() }, indication = null) {
                        when {
                            state.phase == Phase.Off && localPhase == LocalPhase.Idle -> startListening()
                            state.phase == Phase.Speaking -> onInterrupt()
                        }
                    },
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("JARVIS", color = Color(0xFFE6FCFF), fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("AI CORE", color = HudCyan, fontSize = 8.sp, letterSpacing = 2.4.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                AnimatedContent(now.title, label = "jarvis-status") { title ->
                    Text(title, color = HudCyan, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }
                Text(now.hint, color = if (problem) HudWarning else HudMuted, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Text("●  16KHz\n●  LOCAL WAKE", color = HudMuted, fontSize = 8.sp, lineHeight = 13.sp, textAlign = TextAlign.End)
        }

        val recentTask = task?.takeIf { now.live || System.currentTimeMillis() - it.at < TASK_SHOWN_MS }
        recentTask?.let { TaskCard(it, Modifier.fillMaxWidth().padding(top = 8.dp)) }

        if (state.phase != Phase.Off && state.lines.isNotEmpty()) {
            Conversation(state.lines, Modifier.fillMaxWidth().weight(0.85f).padding(top = 8.dp))
        } else {
            Spacer(Modifier.height(8.dp))
            QuickActions(onQuick, favourites)
            Recent(activity.take(2), onSeeActivity)
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilledIconButton(
                onClick = { if (now.live) onStop() else startListening() },
                modifier = Modifier.size(62.dp).border(1.dp, HudCyan.copy(alpha = 0.5f), CircleShape),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = if (now.live) Color(0xFF153143) else Color(0xFF0C526A),
                    contentColor = Color(0xFFE6FCFF),
                ),
            ) {
                Icon(if (now.live) Icons.Filled.Close else MicIcon, contentDescription = if (now.live) "Stop" else "Talk", modifier = Modifier.size(26.dp))
            }
        }
    }
}

@Composable
private fun QuickActions(onQuick: (LocalCommand) -> String, favourites: List<LocalCommand>) {
    var answer by remember { mutableStateOf<String?>(null) }
    var torchOn by remember { mutableStateOf(false) }
    val learned = favourites.mapNotNull { command ->
        HabitKeys.key(command)?.let { HabitKeys.describe(it).replaceFirstChar(Char::uppercase) to { command } }
    }
    val defaults = listOf(
        (if (torchOn) "LIGHT OFF" else "LIGHT") to {
            torchOn = !torchOn
            LocalCommand.Torch(torchOn)
        },
        "BATTERY" to { LocalCommand.Battery },
        "TIME" to { LocalCommand.Time },
        "PAUSE" to { LocalCommand.Media(MediaKey.Pause) },
    )
    val actions = (learned + defaults.filter { d -> learned.none { it.first.startsWith(d.first, ignoreCase = true) } }).take(4)
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("QUICK COMMANDS", color = HudMuted, fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f))
            Text("LOCAL", color = HudCyan, fontSize = 8.sp, letterSpacing = 1.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
            actions.forEach { (label, command) ->
                Box(
                    Modifier.weight(1f).background(HudPanel, RoundedCornerShape(8.dp)).border(1.dp, HudLine, RoundedCornerShape(8.dp))
                        .clickable { answer = onQuick(command()) }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, color = HudCyan, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, letterSpacing = 0.5.sp)
                }
            }
        }
        answer?.let { Text(it, color = HudMuted, fontSize = 10.sp, modifier = Modifier.padding(top = 5.dp, start = 3.dp)) }
    }
}

@Composable
private fun Recent(entries: List<ActivityLog.Entry>, onSeeAll: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("ACTIVITY LOG", color = HudMuted, fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = onSeeAll) { Text("VIEW ALL", color = HudCyan, fontSize = 9.sp) }
    }
    if (entries.isEmpty()) {
        Text("No recent operations.", color = HudMuted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(start = 3.dp))
    } else {
        entries.forEach { entry ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("›", color = HudCyan, fontSize = 13.sp)
                Text(entry.what, color = Color(0xFFD6E9F0), fontSize = 10.sp, modifier = Modifier.weight(1f).padding(start = 7.dp), maxLines = 1)
                Text(entry.result, color = HudMuted, fontSize = 9.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun Conversation(lines: List<Line>, modifier: Modifier) {
    val list = rememberLazyListState()
    LaunchedEffect(lines.size, lines.lastOrNull()?.text) {
        if (lines.isNotEmpty()) list.animateScrollToItem(lines.lastIndex)
    }
    LazyColumn(modifier, state = list, verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(lines, key = { it.id }) { line ->
            Box(Modifier.fillMaxWidth(), contentAlignment = if (line.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                Text(
                    line.text,
                    color = if (line.fromUser) Color(0xFF00151D) else Color(0xFFDDF8FF),
                    fontSize = 12.sp,
                    modifier = Modifier
                        .background(if (line.fromUser) HudCyan else HudPanel, RoundedCornerShape(12.dp))
                        .border(1.dp, if (line.fromUser) HudCyan else HudLine, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }
    }
}

private const val TASK_SHOWN_MS = 2 * 60_000L
