package app.shilex.android.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import app.shilex.android.assistant.Phase
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val Cyan = Color(0xFF38E8FF)
private val Blue = Color(0xFF1689D8)
private val DeepBlue = Color(0xFF062A48)
private val DimCyan = Color(0xFF15516B)

/** JARVIS-style reactor: concentric HUD rings, radial ticks and a scanning arc. */
@Composable
fun Orb(phase: Phase, modifier: Modifier = Modifier, level: Float = 0f) {
    val transition = rememberInfiniteTransition(label = "jarvis-hud")
    val speed = if (phase == Phase.Off) 22_000 else 7_000
    val rotation = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(speed, easing = LinearEasing)),
        label = "rotation",
    ).value
    val counterRotation = (rotation * -0.62f) % 360f
    val pulse = (0.5f + 0.5f * sin(rotation * PI.toFloat() / 180f))
    val active = phase != Phase.Off
    val energy = (if (active) 0.24f + pulse * 0.12f else 0.10f) + level.coerceIn(0f, 1f) * 0.22f

    Canvas(modifier) {
        val c = center
        val radius = size.minDimension * 0.43f
        val thin = 1.1f * density
        val thick = 2.2f * density

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Cyan.copy(alpha = energy), DeepBlue.copy(alpha = 0.34f), Color.Transparent),
                center = c,
                radius = radius * 1.42f,
            ),
            radius = radius * 1.42f,
            center = c,
        )

        listOf(0.48f, 0.62f, 0.78f, 0.96f, 1.12f).forEachIndexed { index, scale ->
            drawCircle(
                color = DimCyan.copy(alpha = if (index == 4) 0.45f else 0.68f),
                radius = radius * scale,
                center = c,
                style = Stroke(width = if (index == 2) thick else thin),
            )
        }

        // Fine radial graduations around the outside of the reactor.
        for (i in 0 until 72) {
            val angle = i * (2f * PI.toFloat() / 72f)
            val major = i % 6 == 0
            val inner = radius * if (major) 1.00f else 1.055f
            val outer = radius * 1.13f
            drawLine(
                color = Cyan.copy(alpha = if (major) 0.9f else 0.35f),
                start = Offset(c.x + cos(angle) * inner, c.y + sin(angle) * inner),
                end = Offset(c.x + cos(angle) * outer, c.y + sin(angle) * outer),
                strokeWidth = if (major) 1.7f * density else 0.8f * density,
            )
        }

        // Two independently rotating segmented arcs.
        rotate(rotation) {
            drawArc(
                color = Cyan.copy(alpha = 0.95f),
                startAngle = 8f,
                sweepAngle = 72f,
                useCenter = false,
                topLeft = Offset(c.x - radius * 1.12f, c.y - radius * 1.12f),
                size = Size(radius * 2.24f, radius * 2.24f),
                style = Stroke(width = thick, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
            drawArc(
                color = Blue.copy(alpha = 0.75f),
                startAngle = 188f,
                sweepAngle = 46f,
                useCenter = false,
                topLeft = Offset(c.x - radius * 1.12f, c.y - radius * 1.12f),
                size = Size(radius * 2.24f, radius * 2.24f),
                style = Stroke(width = thick),
            )
        }
        rotate(counterRotation) {
            drawArc(
                color = Cyan.copy(alpha = 0.55f),
                startAngle = 28f,
                sweepAngle = 104f,
                useCenter = false,
                topLeft = Offset(c.x - radius * 0.82f, c.y - radius * 0.82f),
                size = Size(radius * 1.64f, radius * 1.64f),
                style = Stroke(width = thin),
            )
        }

        // Central energy core and its fine targeting circle.
        drawCircle(color = Cyan.copy(alpha = 0.12f + energy * 0.22f), radius = radius * 0.42f, center = c)
        drawCircle(color = Cyan.copy(alpha = 0.85f), radius = radius * 0.31f, center = c, style = Stroke(width = thick))
        drawCircle(
            brush = Brush.radialGradient(listOf(Color(0xFFB9FAFF), Cyan.copy(alpha = 0.8f), DeepBlue), c, radius * 0.31f),
            radius = radius * 0.25f,
            center = c,
        )
        drawCircle(color = Color.White.copy(alpha = 0.72f), radius = radius * 0.035f, center = c)

        // Small crosshair marks make the centre read as a technical instrument.
        val gap = radius * 0.54f
        val arm = radius * 0.10f
        drawLine(Cyan.copy(alpha = 0.52f), Offset(c.x - gap - arm, c.y), Offset(c.x - gap + arm, c.y), thin)
        drawLine(Cyan.copy(alpha = 0.52f), Offset(c.x + gap - arm, c.y), Offset(c.x + gap + arm, c.y), thin)
        drawLine(Cyan.copy(alpha = 0.52f), Offset(c.x, c.y - gap - arm), Offset(c.x, c.y - gap + arm), thin)
        drawLine(Cyan.copy(alpha = 0.52f), Offset(c.x, c.y + gap - arm), Offset(c.x, c.y + gap + arm), thin)
    }
}
